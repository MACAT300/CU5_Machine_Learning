"""
Test package for OutlierCleaner
""" 